<?php
$con=mysqli_connect('localhost','root', '' ,'riveyrainfotech')or die('not connected');
?>