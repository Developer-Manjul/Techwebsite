<?php include('connection.php');


if (isset($_POST["submit"]))

{

$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$subject=$_POST['subject'];
$message=$_POST['message'];


$q="INSERT INTO `userdetails`(`name`, `email`, `phone`, `subject`, `message`) 
VALUES ('[$name]','[$email]','[$phone]','[$subject]','[$message]')";
// $q="INSERT INTO userdetails(name,email,phone,subject,message)

//  VALUES ('$name', '$email' '$phone','$subject','$message')";

$res=mysqli_query($con,$q);
if ($res){
	echo "<script>

	window.location.href='index.php';

	

	 </script>";
}


else{

	echo"User not created";

}



}

?>


