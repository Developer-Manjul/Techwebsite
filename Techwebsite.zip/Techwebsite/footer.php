<footer class="main-footer footer-two pt-80 bgc-lighter">
    

            <div class="container1">
                <div class="row justify-content-xl-between justify-content-center">
                    <div class="col-xl-4 col-lg-5 col-md-6">
                        <div class="footer-widget widget_about me-md-5 wow fadeInUp delay-0-2s">

                            <div class="footer-logo mb-25">
                                <a href="index.php"><img src="assets/images/logos/logo7.png" alt="Logo" style="width: 100%;"></a>
                            </div>
                            <p style="color:#fff">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremq dantium, totam rem aperiam eaqu quae ab illo inventore veritatis et quasi architecto beatae</p>
                           
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="footer-widget widget_nav_menu wow fadeInUp delay-0-4s">
                            <h4 class="footer-title" style="color:#ffff">Quick Links</h4>
                            <ul class="list-style-two">
                                <li><a href="service-details.php" style="color:#fff">Wed Design (UI/UX)</a></li>
                                <li><a href="about.php"style="color: #fff;">About company</a></li>
                                <li><a href="service-details.php" style="color:#fff">Web development</a></li>
                                <li><a href="team.php" style="color:#fff">Meet our teams</a></li>
                                <li><a href="service-details.php" style="color:#fff">SEO Optimization</a></li>
                                <li><a href="service-details.php" style="color:#fff">Case Stories</a></li>
                                <li><a href="service-details.php" style="color:#fff">Product Engineering</a></li>
                                <li><a href="service-details.php" style="color:#fff">Technical Support</a></li>
                                <li><a href="contact.php" style="color: #fff;">Contact</a></li>
                                <li><a href="service-details.php" style="color:#fff">Landing Pages Design</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-8">
                        <h4 style="color:#ffffff">Follow Us</h4>
                         <div class="social-style-two pt-5">
                                <a href="https://www.facebook.com/RiveyraInfotech/"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom mt-5 pt-5 pb-5">
                <div class="container">
                    <div class="copyright-text text-center" style="color:red">
                        <p>© Copyright 2022 Riveyra Infotech . All right reserved</p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer area end -->
        