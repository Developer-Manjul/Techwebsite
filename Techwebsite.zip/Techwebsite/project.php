<?php include('header.php');?>

        
        
        <!-- Page Banner Start -->
        
        <section class="page-banner-area pt-150 rpt-100 pb-100 rpb-100 rel z-1 bgc-black text-center">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s" style="color:#fff">Project <span></span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="index.php" style="color:#fff">home</a></li>
                            <li class="breadcrumb-item active" style="color:#fff">Project</li>
                        </ol>
                    </nav>
                </div>
            </div>
           <!--  <div class="banner-shapes">
                
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div> -->
        </section>
        <!-- Page Banner End -->
        
        
        <!-- Project Area start -->
        <section class="project-page-area pt-130 pb-100 rel z-1">
            <div class="container">
                <div class="row justify-content-between align-items-end pb-30">
                    <div class="col-xl-6">
                        <div class="section-title mb-30 wow fadeInUp delay-0-2s">
                            <span class="sub-title style-two mb-15">Pre-made Template</span>
                            <h2>Let’s See Our Popular Website Template</h2>
                        </div>
                    </div>
                    <div class="col-xl-6 text-xl-end">
                        <ul class="project-filter filter-btns-one d-inline-flex mb-30 wow fadeInUp delay-0-4s">
                            <li data-filter="*" class="current">All</li>
                            <!-- <li data-filter=".business">Business</li>
                            <li data-filter=".medical">Medical</li>
                            <li data-filter=".construction">Construction</li>
                            <li data-filter=".education">Education</li> -->
                        <!-- </ul> -->
                    </div>
                </div>
                <div class="row project-active justify-content-center">
                    <div class="col-xl-4 col-md-6 item saas construction">
                        <div class="project-item style-two wow fadeInUp delay-0-2s">
                            <div class="project-iamge">
                                <img src="assets/images/projects/ss1.png" alt="Project">
                                <div class="project-over">
                                    <a class="details-btn" href="https://sdrfup.in/"><i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="project-content">
                                <h5><a href="https://sdrfup.in/"> SDRF Website  </a></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 item business medical education">
                        <div class="project-item style-two wow fadeInUp delay-0-4s">
                            <div class="project-iamge">
                                <img src="assets/images/projects/ss2.png" alt="Project">
                                <div class="project-over">
                                    <a class="details-btn" href="https://skinmiraclekanpur.in/"><i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="project-content">
                                <h5><a href="https://skinmiraclekanpur.in/"> Responsive Website  <br>Template</a></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 item business medical education">
                        <div class="project-item style-two wow fadeInUp delay-0-4s">
                            <div class="project-iamge">
                                <img src="assets/images/projects/ss3.png" alt="Project">
                                <div class="project-over">
                                    <a class="details-btn" href="https://ssconstruction.in/"><i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="project-content">
                                <h5><a href="https://ssconstruction.in/"> Construction Website</a></h5>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                   
                    
                   
                    
                    
                           
                    
                    

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Project Area end -->
        
        
        <!-- Call to Action Area start -->
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.html" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Get Started <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->

        <?php include('footer.php');?>
        
        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/projects.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:11:10 GMT -->
</html>