<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from demo.webtend.net/html/oxence/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:07:59 GMT -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Riveyra Infotec Pvt. Ltd.</title>
    <!-- Favicon Icon -->
    <!-- <link rel="shortcut icon" href="assets/images/favicon1.png" type="image/x-icon"> -->
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@400;500;600&amp;family=Kumbh+Sans:wght@400;500;700&amp;family=Shadows+Into+Light&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style2.css">
    
    <!-- Flaticon -->
    <link rel="stylesheet" href="assets/css/flaticon.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/fontawesome-5.14.0.min.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/nice-select.min.css">
    <!-- Type Writer -->
    <link rel="stylesheet" href="assets/css/jquery.animatedheadline.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Slick -->
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <!-- Main Style -->
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>
<body class="home-one">
    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="#"></div>

        <!-- main header -->
        <header class="main-header header-two">
            <!--Header-Upper-->
            <div class="header-upper">
                <div class="container clearfix">

                    <div class="header-inner rel d-flex align-items-center">
                        <div class="logo-outer">
                            <div class="logo"><a href="index.php"><img src="assets/images/logos/2.png" alt="Logo" title="Logo"></a></div>
                        </div>

                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu navbar-expand-lg">
                                <div class="navbar-header">
                                   <div class="mobile-logo my-15">
                                       <a href="index.php">
                                            <img src="assets/images/logos/2.png" alt="Logo" title="Logo">
                                       </a>
                                   </div>
                                   
                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-bs-toggle="collapse" data-bs-target=".navbar-collapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">
                                        <li class=><a href="index.php">Home</a>
                                        <li><a href="about.php">About</a></li>
                                        <li class="#"><a href="services.php">services</a>
                                            <!-- <ul>
                                                <li><a href="services.php">Popular Services</a></li>
                                                <li><a href="service-details.php">service details</a></li>
                                            </ul> -->
                                        </li>
                                        <li class="#"><a href="project.php">Project</a>
                                            <ul>
                                                <li><a href="project.php">Project Grid</a></li>
                                         
                                            </ul>
                                        </li>
                                        
                                            
                                        </li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>

                            </nav>
                            <!-- Main Menu End-->
                        </div>
                        
                        <!-- Menu Button -->
                        <div class="menu-btns">
                           <a href="contact.php" class="theme-btn style-three">Call Us Now<i class="fas fa-angle-double-right"></i></a>
                           
                            <!-- menu sidbar -->
                            <div class="menu-sidebar">
                                <button>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->
        </header>