<?php include('header.php');?>        
        
        <!-- Page Banner Start -->
        <section class="page-banner-area pt-150 rpt-100 pb-100 rpb-100 rel z-1 bgc-black text-center">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s" style="color:#fff">Conta<span>ct Us</span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="index.php" style="color:#fff" >home</a></li>
                            <li class="breadcrumb-item active" style="color:#fff" >Contact</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!-- <div class="banner-shapes">
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div> -->
        </section>
        <!-- Page Banner End -->
        
        
        <!-- Contact Us Page Area start -->
        <section class="contact-us-page-area py-130">
            <div class="container">
                <div class="row align-items-end justify-content-between">
                    <div class="col-lg-7">
                        <div class="contact-content rmb-65 wow fadeInRight delay-0-2s">
                            <div class="section-title mb-25">
                                <span class="sub-title style-two mb-15">Contact Us</span>
                                <h2>Let’s Start New Project or work Together! Contact With us</h2>
                            </div>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque lauda tiumes totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto</p>
                            <form   action="insert.php" name="contactForm" method="post" enctype="multipart/form-data" >
                                <div class="row pt-15">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name">Full Name</label>
                                            <input type="text" name="name" class="form-control" value="" placeholder="Full Name" required data-error="Please enter your name">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email">Email Address</label>
                                            <input type="email"  name="email" class="form-control" value="" placeholder="Enter your e-mail address" required data-error="Please enter your Email">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Phone Number</label>
                                            <input type="text" name="phone" class="form-control" value="" placeholder="Enter Your Mobile Number">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-30">
                                        <div class="form-group">
                                           <label for="select-subject">Select Requirments</label>
                                           <select name="subject" >
                                                <option value="default" selected="">Website customize</option>
                                                <option value="Design">Design</option>
                                                <option value="Development">Development</option>
                                                <option value="SEO">SEO</option>
                                            </select>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="message">Write Message</label>
                                            <textarea name="message" class="form-control" rows="4" placeholder="Write Message" required data-error="Please enter your Message"></textarea>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group pt-5 mb-0">
                                            <button type="submit" name="submit" class="theme-btn w-100">Send Message <i class="fas fa-angle-double-right"></i></button>
                                            <!-- <div id="msgSubmit" class="hidden"></div> -->
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <div class="contact-info wow fadeInLeft delay-0-2s">
                            <div class="contact-info-item style-two">
                                <div class="icon">
                                    <i class="fal fa-map-marker-alt"></i>
                                </div>
                                <div class="content">
                                    <span class="title">Location</span>
                                    <span class="text">64,Lakhanpur Housing
                                    Society Brhind Lucky Resturant, Vikas Nagar, Kanpur, Uttar Pradesh 208024</span>
                                </div>
                            </div>
                            <div class="contact-info-item style-two">
                                <div class="icon">
                                    <i class="far fa-envelope-open-text"></i>
                                </div>
                                <div class="content">
                                    <span class="title">email address</span>
                                    <span class="text">
                                        <a href="https://demo.webtend.net/cdn-cgi/l/email-protection#473432373728353307202a262e2b6924282a"><span class="__cf_email__" data-cfemail="473432373728353330222507202a262e2b6924282a"> sales@riveyrainfotec.com]</span></a><br>
                                        <a href="https://demo.webtend.net/cdn-cgi/l/email-protection#a3d4c6c1d0cad7c6c1d6cacfc7cacdc48dcdc6d7">Website-www.riveyrainfotec.com</a>
                                    </span>
                                </div>
                            </div>
                            <div class="contact-info-item style-two">
                                <div class="icon">
                                    <i class="far fa-phone"></i>
                                </div>
                                <div class="content">
                                    <span class="title">Phone Number</span>
                                    <span class="text">
                                        Call <a href="calto:+000(123)45688">+91 9919888269</a><br>
                                        Whatsapp : +9632145789
                                    </span>
                                </div>
                            </div>
                            <div class="follow-us">
                                <h4>Follow Us</h4>
                                <div class="social-style-two">
                                    <a href="https://www.facebook.com/RiveyraInfotech/"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#"><i class="fab fa-behance"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Us Page Area end -->
        
        
        <!-- Our Location Address Area start -->
        <section class="our-location-address-area rel z-1">
            <div class="container">
                <div class="row medium-gap justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="location-address-item wow fadeInUp delay-0-2s">
                            <div class="top-part">
                                <h5>Kanpur</h5>
                            </div>
                            <div class="bottom-part">
                                <ul>
                                    <li><i class="fal fa-map-marker-alt"></i> 64,Lakhanpur Housing Society Behind Lucky Restaurant,Vikas Nagar,, Kanpur, Uttar Pradesh 208024</li>
                                    <li><i class="far fa-envelope-open-text"></i> <a href="https://demo.webtend.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="6c1f191c1c031e182c0b010d0500420f0301">[email-sales@riveyrainfotec.com]</a></li>
                                    <li><i class="far fa-phone"></i> +91 9919888269</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </section>
        <!-- Our Location Address Area end -->
        
        
        <!-- Location Map Area Start -->
        <div class="contact-page-map wow fadeInUp delay-0-2s">
            <div class="our-location">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3570.8287563767385!2d80.27670641435614!3d26.49345798439204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399c38238592b8d7%3A0xa45ee9c66ee0b923!2sRiveyra%20Infotech%20Private%20Limited!5e0!3m2!1sen!2sin!4v1664925116026!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
        <!-- Location Map Area End -->
        
        
        <!-- Call to Action Area start -->
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.php" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Get Started <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->
       
       <?php include('footer.php');?>

        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>
    
    <!-- For Contact Form -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="assets/js/form-validator.min.js"></script>
    <script src="assets/js/contact-form-script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:12:47 GMT -->
