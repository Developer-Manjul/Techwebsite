<?php include('header.php');?>
        
        
        <!-- Page Banner Start -->
        <section class="page-banner-area pt-150 rpt-100 pb-100 rpb-100 rel z-1 bgc-black text-center">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s" style="color:#fff">Popular Se<span>rvices</span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="index.php" style="color:#fff">home</a></li>
                            <li class="breadcrumb-item active" style="color:#fff">Popular Services</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!-- <div class="banner-shapes">
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div> -->
        </section>
        <!-- Page Banner End -->
        
        
        <!-- Statistics Five Area start -->
        <section class="statistics-area-five py-130">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-6">
                        <div class="statistics-five-content mb-30 rmb-65 wow fadeInRight delay-0-2s">
                            <div class="section-title mb-25">
                                <span class="sub-title style-two mb-15">Company Statistics</span>
                                <h2>Discover Extraordinary projects brought to life on Riveyra Infotec Pvt. Ltd.</h2>
                            </div>
                            <p>Start building your first prototype in no time. Riveyra intuitive, drag & drop interface gives you all the building blocks that you need to get started! No skills required.</p>
                            <a href="about.html" class="theme-btn mt-15">Learn More <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="statistics-five-image wow fadeInLeft delay-0-2s">
                            <img src="assets/images/logos/4.jpg" alt="Statistics">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Statistics Five Area end -->
        
        
        <!-- Working Process Area start -->
        <section class="work-process-area pb-95 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="section-title text-center mb-55 wow fadeInUp delay-0-2s">
                            <span class="sub-title style-two mb-15">Working Process</span>
                            <h2>How does we works</h2>
                        </div>
                    </div>
                </div>
                <div class="work-process-wrap rel z-1">
                    <div class="row justify-content-between">
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-30 wow fadeInUp delay-0-2s">
                                <div class="icon">
                                    <span class="number">01</span>
                                    <i class="flaticon-optimization"></i>
                                </div>
                                <h4>Info Gathering</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item wow fadeInUp delay-0-4s">
                                <div class="icon">
                                    <span class="number">02</span>
                                    <i class="flaticon-link"></i>
                                </div>
                                <h4>Idea Planning</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-55 wow fadeInUp delay-0-6s">
                                <div class="icon">
                                    <span class="number">03</span>
                                    <i class="flaticon-data"></i>
                                </div>
                                <h4>Design Analysis</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-45 wow fadeInUp delay-0-8s">
                                <div class="icon">
                                    <span class="number">04</span>
                                    <i class="flaticon-star"></i>
                                </div>
                                <h4>Testing & Lunch</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                    </div>
                    <div class="work-process-shape">
                        <img src="assets/images/shapes/worp-process-step.png" alt="Shape">
                    </div>
                </div>
            </div>
        </section>
        <!-- Working Process Area end -->
        
        
        <!-- Services Area start -->
        <section class="services-area-four bgc-black pt-130 pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-10">
                        <div class="section-title text-center text-white mb-60 wow fadeInUp delay-0-2s">
                            <span class="sub-title style-two mb-20">Services We Provide</span>
                            <h2>Popular Web Services</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/services/service-four1.png" alt="Service">
                            </div>
                            <h5>Website Creation from Figma, XD or Photoshop</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red;">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/services/services14.jpg" alt="Service">
                            </div>
                            <h5>Mobile App Development and Website Design</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services15.png" alt="Service">
                            </div>
                            <h5>eCommerce and Product Selling Development</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/services/service-four4.png" alt="Service">
                            </div>
                            <h5>Responsive Websites (UI/UX) Design</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/services/services17.png" alt="Service">
                            </div>
                            <h5>SEO (Search Engine Optimization)</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services18.jpg" alt="Service">
                            </div>
                            <h5>Digital Product Design and Development</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                
           
             <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/service5.jpg" alt="Service">
                            </div>
                            <h5>PHP Development</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red;">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                     
                     <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services6.jpg" alt="Service">
                            </div>
                            <h5>Wordpress Development</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                 <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services7.jpg" alt="Service">
                            </div>
                            <h5>I phone App Development</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                     
                      <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services8.jpg" alt="Service">
                            </div>
                            <h5>Digital Marketing</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services9.jpg" alt="Service">
                            </div>
                            <h5>PPC Advertising</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>


                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services10.png" alt="Service">
                            </div>
                            <h5>Content Writing</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services11.png" alt="Service">
                            </div>
                            <h5>Reputation Management</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red;">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services12.jpg" alt="Service">
                            </div>
                            <h5>Web Analytics</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6">
                        <div class="service-item-four wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/services/services13.jpg" alt="Service">
                            </div>
                            <h5>Social Media Marketing</h5>
                            <a href="service-details.php" class="theme-btn style-three" style="color:red">Service Details <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>


                     </div> 
                 </div>
        </section>

        <!-- Services Area end -->
        
        
        
        <!-- Call to Action Area start -->
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.php" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Get Started <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->

        <?php include('footer.php');?>
        
        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:10:53 GMT -->
</html>