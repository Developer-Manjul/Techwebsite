<?php include('header.php');?>
        
        
        <!-- Page Banner Start -->
        <section class="page-banner-area pt-245 rpt-150 pb-170 rpb-100 rel z-1 bgc-lighter text-center">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s">Expert <span>Team</span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="">home</a></li>
                            <li class="breadcrumb-item active">Expert Team</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="banner-shapes">
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div>
        </section>
        <!-- Page Banner End -->
        
        
        <!-- Support & Marketing Area start -->
        <section class="support-marketing-area py-130 rel z-1">
            <div class="container">
                <div class="row large-gap justify-content-between align-items-center">
                    <div class="col-lg-6">
                        <div class="support-marketing-progress rmb-65 wow fadeInLeft delay-0-2s">
                            <div class="section-title mb-35">
                                <span class="sub-title style-two mb-15">Best Skills</span>
                                <h2>We are Much Experience in Website Design</h2>
                            </div>
                            <p>Fortunately, we aren’t just designers and developers here—we are writers, strategists, techs and creatives, all working towards the same end goal: our client’s success. As a full-service digital marketing agency</p>
                            <div class="circle-counter">
                                <div class="circle-progress-item">
                                    <div class="progress-content one">
                                        <h3>0</h3>
                                    </div>
                                    <h5>SEO Service</h5>
                                </div>
                                <div class="circle-progress-item">
                                    <div class="progress-content two">
                                        <h3>0</h3>
                                    </div>
                                    <h5>Copywriting</h5>
                                </div>
                                <div class="circle-progress-item">
                                    <div class="progress-content three">
                                        <h3>0</h3>
                                    </div>
                                    <h5>PPC</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="best-skills-image wow fadeInRight delay-0-2s">
                            <img src="assets/images/about/best-skills.jpg" alt="Best Skills">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Support & Marketing Area start -->
        
        
        <!-- Team Area start -->
        <section class="team-page-area pb-65 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-7">
                        <div class="section-title text-center mb-50 wow fadeInUp delay-0-2s">
                            <span class="sub-title style-two mb-15">Amazing Team</span>
                            <h2>We Have Well Experience Team Member</h2>
                        </div>
                    </div>
                </div>
                <ul class="team-filter filter-btns-two justify-content-center mb-30 wow fadeInUp delay-0-4s">
                    <li data-filter="*" class="current">Show All</li>
                </ul>
                <div class="row team-active justify-content-center">
                    <div class="col-xl-3 col-lg-4 col-md-6 item developer seo-expert">
                        <div class="team-member">
                            <div class="image">
                                <img src="assets/images/team/member1.jpg" alt="Member">
                            </div>
                            <div class="content">
                                <h5><a href="team-profile.html">Vaibhav Gupta</a></h5>
                                <span class="designation">CEO</span>
                                <span class="designation">Director</span>
                                <div class="social-style-one">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6 item desiger logo-designer">
                        <div class="team-member">
                            <div class="image">
                                <img src="assets/images/team/member2.jpg" alt="Member">
                            </div>
                            <div class="content">
                                <h5><a href="team-profile.html">Richard C. Harrison</a></h5>
                                <span class="designation">Web Developer</span>
                                <div class="social-style-one">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6 item engineer seo-expert">
                        <div class="team-member">
                            <div class="image">
                                <img src="assets/images/team/member3.jpg" alt="Member">
                            </div>
                            <div class="content">
                                <h5><a href="team-profile.html">Vishal Soni</a></h5>
                                <span class="designation">Developer</span>
                                <div class="social-style-one">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div> 

                </div>
            </div>
        </section>
        <!-- Team Area end -->
        
        
        <!-- Call to Action Area start -->
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.php" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Get Started <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->
        <?php include('footer.php');?>
       
        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/team.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:11:37 GMT -->
</html>