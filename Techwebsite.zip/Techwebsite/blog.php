<?php include('header.php');?>
        
        <!-- Page Banner Start -->
        <section class="page-banner-area pt-245 rpt-150 pb-170 rpb-100 rel z-1 bgc-lighter text-center">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s">Blog Grid <span>View</span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="index.php">home</a></li>
                            <li class="breadcrumb-item active">Blog Grid</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="banner-shapes">
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div>
        </section>
        <!-- Page Banner End -->
        
        
        <!-- Blog Grid Area start -->
        <section class="blog-grid-area py-130 rel z-1">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid1.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">How To Build Group Chat App With Vanilla JS, Twilio And Node.js</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                                <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid2.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">Smashing Podcast Episode 47 With Sara Soueidan Does Accessibility</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                                <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid3.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">Manage Accessible Design System With CSS Color-Contrast</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                                <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid4.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">How To Build Group Chat App With Vanilla JS, Twilio And Node.js</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                                <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid5.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">Smashing Podcast Episode 47 With Sara Soueidan Does Accessibility</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                               <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                   
                    
                    
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-grid-item wow fadeInUp delay-0-6s">
                            <div class="image">
                                <img src="assets/images/blog/blog-grid9.jpg" alt="Blog Grid">
                            </div>
                            <div class="blog-content">
                                <ul class="blog-meta">
                                    <li>
                                        <img src="assets/images/blog/blog-author.jpg" alt="Author">
                                        <a href="#">Somalia D. Silva</a>
                                    </li>
                                    <li>
                                        <i class="far fa-calendar-alt"></i>
                                        <a href="#">25 June 2022</a>
                                    </li>
                                </ul>
                                <h5><a href="blog-details.html">Manage Accessible Design System With CSS Color-Contrast</a></h5>
                                <p>Sit amet consectetur adipiscin eiusmod temor incididunt labore dolore magnaes epse</p>
                                <a class="read-more" href="blog-details.html">Read More <i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <ul class="pagination flex-wrap justify-content-center wow fadeInUp delay-0-2s">
                    <li class="page-item disabled">
                        <span class="page-link"><i class="fas fa-angle-left"></i></span>
                    </li>
                    <li class="page-item active">
                        <span class="page-link">
                            01
                            <span class="sr-only">(current)</span>
                        </span>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">02</a></li>
                    <li class="page-item"><a class="page-link" href="#">03</a></li>
                    <li class="page-item dot"></li>
                    <li class="page-item dot"></li>
                    <li class="page-item dot"></li>
                    <li class="page-item">
                        <a class="page-link" href="#"><i class="fas fa-angle-right"></i></a>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Blog Grid Area end -->
        
        
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.html" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Get Started <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->
       
       <?php include('footer.php');?>
        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/blog.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:12:21 GMT -->
</html>