<?php include('header.php');?>
       
       
        <!--Form Back Drop-->
        <div class="form-back-drop"></div>
        
        <!-- Hidden Sidebar -->
        <section class="hidden-bar">
            <div class="inner-box text-center">
                <div class="cross-icon"><span class="fa fa-times"></span></div>
                <div class="title">
                    <h4>Get Appointment</h4>
                </div>

                <!--Appointment Form-->
                <div class="appointment-form">
                    <form method="post" action="https://demo.webtend.net/html/oxence/contact.php">
                        <div class="form-group">
                            <input type="text" name="text" value="" placeholder="Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" value="" placeholder="Email Address" required>
                        </div>
                        <div class="form-group">
                            <textarea placeholder="Message" rows="5"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="theme-btn">Submit now</button>
                        </div>
                    </form>
                </div>

                <!--Social Icons-->
                <div class="social-style-one">
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                </div>
            </div>
        </section>
        <!--End Hidden Sidebar -->
       
        
        <!-- Slider Section Start -->
        <section class="main-slider-area bgc-black rel z-1">
           <div class="main-slider-active">
                <div class="slider-item">
                    <div class="container">
                        <div class="slider-content">
                        
                            <h1 style="font-size:;"> Web design and <span>digital</span>solutions agency</h1>
                            <div class="slider-btns">
                                <a href="contact.php" class="theme-btn">Get Intersted <i class="fas fa-angle-double-right"></i></a>
                                <a href="services.php" class="theme-btn style-three">Services <i class="fas fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="slider-video" style="background-image: url(assets/images/slider/slider3.jpg);">
                        <a href="https://www.youtube.com/watch?v=9Y7ma241N8k" class="mfp-iframe video-play"><i class="fas fa-play"></i></a>
                        <span class="video-title cd-headline clip">
                            <span class="cd-words-wrapper">
                                <b class="is-visible">Web Design</b>
                                <b>Development</b>
                            </span>
                        </span>
                    </div>
                </div>
                <div class="slider-item">
                    <div class="container">
                        <div class="slider-content">
                            
                            <h1 style="font-size:;">Web design  and <span>digital</span> solutions agency</h1>
                            <div class="slider-btns">
                                <a href="contact.php" class="theme-btn">Get Intersted <i class="fas fa-angle-double-right"></i></a>
                                <a href="services.php" class="theme-btn style-three">Services <i class="fas fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="slider-video" style="background-image: url(assets/images/slider/slider4.jpg);">
                        <a href="https://www.youtube.com/watch?v=9Y7ma241N8k" class="mfp-iframe video-play"><i class="fas fa-play"></i></a>
                        <span class="video-title cd-headline clip">
                            <span class="cd-words-wrapper">
                                <b class="is-visible">Web Design</b>
                                <b>Development</b>
                            </span>
                        </span>
                    </div>
                </div>
                <div class="slider-item">
                    <div class="container">
                        <div class="slider-content">
                            
                            <h1 style="font-size: ;"> Web design and <span>digital</span> solutions agency</h1>
                            <div class="slider-btns">
                                <a href="contact.php" class="theme-btn">Get Intersted <i class="fas fa-angle-double-right"></i></a>
                                <a href="services.php" class="theme-btn style-three">Services <i class="fas fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="slider-video" style="background-image: url(assets/images/slider/slider5.jpg);">
                        <a href="https://www.youtube.com/watch?v=9Y7ma241N8k" class="mfp-iframe video-play"><i class="fas fa-play"></i></a>
                        <span class="video-title cd-headline clip">
                            <span class="cd-words-wrapper">
                                <b class="is-visible">Web Design</b>
                                <b>Development</b>
                            </span>
                        </span>
                    </div>
                </div>
           </div>
           <div class="container"><div class="main-slider-dots"></div></div>
           <div class="slider-shapes">
               <img class="shape dots one" src="assets/images/shapes/slider-dots.png" alt="Shape">
               <img class="shape dots two" src="assets/images/shapes/slider-dots.png" alt="Shape">
               <img class="shape wave-line" src="assets/images/shapes/slider-wave-line.png" alt="Shape">
               <img class="shape circle" src="assets/images/shapes/slider-circle.png" alt="Shape">
           </div>
        </section>
        <!-- Slider Section End -->
        
        
        <!-- Core Feature start -->
        <section class="feature-area-five bgc-lighter pt-100 pb-70">
            <div class="container">
                <div class="section-title text-center mb-60 wow fadeInUp delay-0-2s">
                    <span class="sub-title mb-10">Core Features</span>
                    <h2>Amazing web design features</h2>
                </div>
                <div class="row row-cols-xl-6 row-cols-lg-4 row-cols-md-3 row-cols-sm-2 row-cols-1 justify-content-center">
                    <div class="col wow fadeInUp delay-0-2s">
                        <div class="feature-item-five">
                            <i class="flaticon-responsive"></i>
                            <h5><a href="service-details.php">Responsive design</a></h5>
                        </div>
                    </div>
                    <div class="col wow fadeInUp delay-0-3s">
                        <div class="feature-item-five">
                            <i class="flaticon-feature"></i>
                            <h5><a href="service-details.php">Powerful Customization</a></h5>
                        </div>
                    </div>
                    <div class="col wow fadeInUp delay-0-4s">
                        <div class="feature-item-five">
                            <i class="flaticon-aim"></i>
                            <h5><a href="service-details.php">Cool & modern animations</a></h5>
                        </div>
                    </div>
                    <div class="col wow fadeInUp delay-0-5s">
                        <div class="feature-item-five">
                            <i class="flaticon-seo"></i>
                            <h5><a href="service-details.php">SEO Friendly Coding</a></h5>
                        </div>
                    </div>
                    <div class="col wow fadeInUp delay-0-6s">
                        <div class="feature-item-five">
                            <i class="flaticon-search-location"></i>
                            <h5><a href="service-details.php">Best Technical supports</a></h5>
                        </div>
                    </div>
                    <div class="col wow fadeInUp delay-0-7s">
                        <div class="feature-item-five">
                            <i class="flaticon-settings"></i>
                            <h5><a href="service-details.php">Varied Layouts & parallax</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Core Feature end -->

       
        <!-- About Us Area start -->
        <section class="about-area-one pt-130 pb-125 rel z-1">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-5">
                        <div class="about-image-one bg-squire-shape rmb-85 wow fadeInUp delay-0-2s">
                            <img src="assets/images/about/code2.jpg" alt="About us">
                            <img class="image-left" src="assets/images/shapes/image-left.png" alt="shape">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-7">
                        <div class="about-content">
                            <div class="section-title mb-45">
                                <span class="sub-title mb-15">About Riveyra Infotech</span>
                                <h2>Best web design solutions agency to growth</h2>
                            </div>
                            <ul class="list-style-one">
                                <li>
                                    <div class="content">
                                        <h4 >Company Mission</h4>
                                        <p>Riveyra Infotech is a web development company aims at providing the best services regarding the website and software development. We provide comprehensive and integrated IT services that includes software development, Website design and development, Mobile application development, Mobile website development, Search Engine Optimization, Online marketing, Graphics Design as well as development and implementation of high quality business domain applications. Our goal is to provide high quality and cost effective services to the internet and IT outsourcing community and business who wish to maximize their reach by harnessing the unlimited power of information technology.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <h4>Company Vision</h4>
                                        <p>We believes we are highly qualified to assist and guide you through a comprehensive website overhaul. We combines strategic thinking and emerging technologies to provide innovative solutions that consistently break new ground.
We develops long-term relationships with our clients. We deliver high-quality work through our focus on bidirectional communication, responsive customer service, client education, accurate project management, product quality, and an ethical approach to business. We have a well-documented track record of performing work on budget and on deadline.
</p>
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Us Area end -->
        
        
        <!-- Statistics Three Area start -->
        <section class="statistics-area-three bgs-cover pb-100 rel z-1">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-7">
                        <div class="statistics-three-content rmb-65 wow fadeInRight delay-0-2s">
                            <div class="row justify-content-center justify-content-xl-start">
                                <div class="col-xl-9">
                                    <div class="section-title mb-60">
                                        <span class="sub-title mb-15">Company Statistics</span>
                                        <h2>We’ve some achievement from global partners</h2>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-6 col-md-4 col-sm-6">
                                    <div class="counter-item style-two counter-text-wrap wow fadeInRight delay-0-3s">
                                        <i class="flaticon-startup"></i>
                                        <span class="count-text" data-speed="3000" data-stop="700">0</span>
                                        <span class="counter-title">Projects complete</span>
                                        <p>On the other denonce with righteous indin</p>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-6 col-md-4 col-sm-6">
                                    <div class="counter-item style-two counter-text-wrap wow fadeInRight delay-0-5s">
                                        <i class="flaticon-global"></i>
                                        <span class="count-text" data-speed="3000" data-stop="1000">0</span>
                                        <span class="counter-title">Global Client’s</span>
                                        <p>On the other denonce with righteous indin</p>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-6 col-md-4 col-sm-6">
                                    <div class="counter-item style-two counter-text-wrap wow fadeInRight delay-0-7s">
                                        <i class="flaticon-rating"></i>
                                        <span class="count-text" data-speed="3000" data-stop="1200">0</span>
                                        <span class="counter-title">Happy Customer</span>
                                        <p>On the other denonce with righteous indin</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="statistics-three-image bg-squire-shape mb-30 wow fadeInLeft delay-0-3s">
                            <img src="assets/images/about/statictics1.png" alt="Statictics">
                            <img class="image-right" src="assets/images/shapes/image-right.png" alt="shape">
                        </div>
                    </div>
                </div>
            </div
        </section>

        <!-- Statistics Three Area end -->
        
        
        <!-- Design Featured Start -->
        <section class="design-feature-area overflow-hidden pt-130 pb-100 text-white bgc-black rel z-1">
           <div class="container">
               <div class="section-title text-center mb-60 wow fadeInUp delay-0-2s">
                    <span class="sub-title mb-10">Core Design Featured</span>
                    <h2>What we provider for website</h2>
                </div>
               <div class="row no-gap align-items-center">
                   <div class="col-lg-3">
                        <div class="feature-left">
                           <div class="row">
                                <div class="col-lg-12 col-sm-6">
                                    <div class="service-item style-three wow fadeInRight delay-0-2s">
                                        <div class="icon"><i class="flaticon-design"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">Website Creation from Scratch</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-sm-6">
                                    <div class="service-item style-three wow fadeInRight delay-0-3s">
                                        <div class="icon"><i class="flaticon-web-page"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">Website maintenance Services</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="falfa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
                   <div class="col-lg-6">
                        <div class="feature-middle rmt-30">
                            <div class="image wow fadeInUp delay-0-2s">
                                <img class="circle-text" src="assets/images/shapes/feature-image-top.png" alt="Text">
                                <img class="round" src="assets/images/features/feature-middle.png" alt="Feature Middle">
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="service-item style-three wow fadeInUp delay-0-3s">
                                        <div class="icon"><i class="flaticon-online"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">eCommerce and product selling</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="service-item style-three mt-30 wow fadeInUp delay-0-4s">
                                        <div class="icon"><i class="flaticon-web-programming"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">Responsive websites (UI/UX) design</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
                   <div class="col-lg-3">
                       <div class="feature-right">
                           <div class="row">
                                <div class="col-lg-12 col-sm-6">
                                    <div class="service-item style-three mt-100 wow fadeInLeft delay-0-2s">
                                        <div class="icon"><i class="flaticon-graphic-design"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">Search Engine Optimization</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-sm-6">
                                    <div class="service-item style-three wow fadeInLeft delay-0-3s">
                                        <div class="icon"><i class="flaticon-user-experience"></i></div>
                                        <div class="content">
                                            <h4><a href="service-details.php">User Experience and Design</a></h4>
                                            <a class="more-btn" href="service-details.php"><i class="fal fa-long-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
               </div>
           </div>
           <div class="design-feature-shapes">
               <img class="shape dots" src="assets/images/shapes/slider-dots.png" alt="Shape">
               <img class="shape wave-line" src="assets/images/shapes/feature-wave-line.png" alt="Shape">
           </div>
        </section>
        <!-- Design Featured End -->

        
        <!-- Project Area start -->
        <section class="project-area-three bgc-black-with-lighting py-130 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg10">
                        <div class="section-title text-center mb-50 wow fadeInUp delay-0-2s">
                            <span class="sub-title mb-15">Recent Projects</span>
                            <h2 style="color:#ffffffff">Look at latest works gallery</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="project-three-active">
                <div class="project-item style-two wow fadeInUp delay-0-2s">
                    <div class="project-iamge">
                        <img src="assets/images/projects/ss1.png" alt="Project">
                        <div class="project-over">
                            <a class="details-btn" href="https://sdrfup.in/"><i class="far fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="project-content">
                        <h4><a href="https://sdrfup.in/" style="color:#fff;">Creative Website design</a></h4>
                        <span class="category">Design Responsive</span>
                    </div>
                </div>
                <div class="project-item style-two wow fadeInUp delay-0-4s">
                    <div class="project-iamge">
                        <img src="assets/images/projects/ss2.png" alt="Project">
                        <div class="project-over">
                            <a class="details-btn" href="https://skinmiraclekanpur.in/"><i class="far fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="project-content">
                        <h4><a href="https://skinmiraclekanpur.in/" style="color:#fff;">Creative Website Design</a></h4>
                        <span class="category">Design Responsive</span>
                    </div>
                </div>
                <div class="project-item style-two wow fadeInUp delay-0-6s">
                    <div class="project-iamge">
                        <img src="assets/images/projects/ss3.png" alt="Project">
                        <div class="project-over">
                            <a class="details-btn" href="https://ssconstruction.in/"><i class="far fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="project-content">
                        <h4><a href="https://ssconstruction.in/" style="color:#fff;" >Creative Website Design</a></h4>
                        <span class="category">Design Responsive</span>
                    </div>
                </div>
            </div>
        </section>
        <!-- Project Area end -->

       
        <!-- Working Process Area start -->
        <section class="work-process-area pb-95 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="section-title text-center mb-55 wow fadeInUp delay-0-2s">
                            <span class="sub-title mb-15">Working Process</span>
                            <h2>How does we works</h2>
                        </div>
                    </div>
                </div>
                <div class="work-process-wrap rel z-1">
                    <div class="row justify-content-between">
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-30 wow fadeInUp delay-0-2s">
                                <div class="icon">
                                    <span class="number">01</span>
                                    <i class="flaticon-optimization"></i>
                                </div>
                                <h4>Info Gathering</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item wow fadeInUp delay-0-4s">
                                <div class="icon">
                                    <span class="number">02</span>
                                    <i class="flaticon-link"></i>
                                </div>
                                <h4>Idea Planning</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-55 wow fadeInUp delay-0-6s">
                                <div class="icon">
                                    <span class="number">03</span>
                                    <i class="flaticon-data"></i>
                                </div>
                                <h4>Design Analysis</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-5 col-sm-6">
                            <div class="work-process-item mt-45 wow fadeInUp delay-0-8s">
                                <div class="icon">
                                    <span class="number">04</span>
                                    <i class="flaticon-star"></i>
                                </div>
                                <h4>Testing & Lunch</h4>
                                <p>Sit amet consectetur adipiscing elit sed eiusmod tempor</p>
                            </div>
                        </div>
                    </div>
                    <div class="work-process-shape">
                        <img src="assets/images/shapes/worp-process-step.png" alt="Shape">
                    </div>
                </div>
            </div>
        </section>
        <!-- Working Process Area end -->
        
        
        <!-- CTA Area start -->
        <section class="call-to-action-area rel z-2">
            <div class="container">
                <div class="cta-inner bgs-cover" style="background-image: url(assets/images/background/cta-bg.jpg);">
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="cta-item wow fadeInLeft delay-0-2s">
                                <div class="icon"><i class="flaticon-target"></i></div>
                                <h4>Have any Project On Minds ?</h4>
                                <a href="contact.php" class="details-btn"><i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="cta-item wow fadeInRight delay-0-2s">
                                <div class="icon"><i class="flaticon-target"></i></div>
                                <h4>We are to work SEO optimization ?</h4>
                                <a href="contact.php" class="details-btn"><i class="far fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- CTA Area end -->
        
        
        
        
        <!-- Testimonial Area Start -->
        <section class="testimonial-area-two rel z-1 mt-130 mb-120">
            <div class="container for-middle-border" style="color:darkred">
                <div class="row justify-content-between align-items-center pb-90 rpb-35 wow fadeInUp delay-0-2s">
                    <div class="col-xl-7 col-lg-8">
                        <div class="section-title">
                            <span class="sub-title mb-15">Clients Testimonials</span>
                            <h2 >Clients feedback</h2>
                        </div>
                    </div>
                    <div class="col-lg-4">
                       <div class="slider-arrow-btns text-lg-end">
                            <button class="work-prev"><i class="far fa-arrow-left"></i></button>
                            <button class="work-next"><i class="far fa-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
                <div class="testimonial-two-active">
                    <div class="testimonial-item-two wow fadeInUp delay-0-2s">
                        <div class="testimonial-author">
                            <img src="assets/images/feedback/testimonial1.jpg" alt="Author">
                        </div>
                        <div class="testimonial-content">
                            <p>They helped create an Ecommerce site for my business, as well as optimized the current site to run as smoothly and efficiently as possible. The team is very professional and works quickly. They have proved to be a valuable partner in the industry, with vast knowledge and incredible support across the company,I would recommend for anyone looking for web development.

Response from the owner4 years ago
Hi Pragya, thank you for the kind words about Riveyra Infotech. It was a pleasure working with you on this eCommerce project, you and the rest of your team were fantastic to work with. We wish you all the best!</p>
                            <div class="author-description">
                                <span class="h5">Ram Singh</span>
                                <span class="designation">CEO & Founder</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item-two wow fadeInUp delay-0-4s">
                        <div class="testimonial-author">
                            <img src="assets/images/feedback/testimonial2.jpg" alt="Author">
                        </div>
                        <div class="testimonial-content">
                            <p>Very happy with your service, keep it up! Riveyra Infotech Strategic Digital Solutions is simply the best. I can see immediate results and an increase in my website's overall reach and performance, and it is all thanks to you.</p>
                            <div class="author-description">
                                <span class="h5">Subham Thakur</span>
                                <span class="designation">Business Consultant</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item-two wow fadeInUp delay-0-2s">
                        <div class="testimonial-author">
                            <img src="assets/images/feedback/testimonial1.jpg" alt="Author">
                        </div>
                        <div class="testimonial-content">
                            <p>I am really impressed by Riveyra Infotech knowledge, experience, and focus, their drive to explore new nooks of website design and development and passion to deliver the best. I was enthralled by the way they transition their thinking and functioning with each phase that brings out the best for the project overall.</p>
                            <div class="author-description">
                                <span class="h5">Surya Awasthi</span>
                                <span class="designation">Business Consultant</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-item-two wow fadeInUp delay-0-4s">
                        <div class="testimonial-author">
                            <img src="assets/images/feedback/testimonial2.jpg" alt="Author">
                        </div>
                        <div class="testimonial-content">
                            <p>Absolutely impressive and functional website by riveyra infotech. Very efficient professional team and good at communication with customer, short out issue if any occur, I want few addition change in my site and they done that on my requirement. I loved especially how very reassured I felt my project was in good hands... cheers guys.
keep doing what you're doing.
Thank you.</p>
                            <div class="author-description">
                                <span class="h5">Rajeev Tripathi</span>
                                <span class="designation">Business Consultant</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonial Area End -->
        
        
        <!-- Contact Area Start -->
        <section class="contact-area overflow-hidden py-130 bgc-black-with-lighting rel z-1">
           <div class="container">
               <div class="row justify-content-between">
                   <div class="col-xl-5 col-lg-6">
                       <div class="contact-info-area text-white rmb-75 wow fadeInLeft delay-0-2s">
                            <div class="section-title mb-55">
                                <h2>Have any project on mind! feel free contact with us or <span>say hello</span></h2>
                            </div>
                            <div class="contact-info-wrap">
                                <div class="contact-info-item">
                                    <div class="icon">
                                        <i class="fal fa-map-marker-alt"></i>
                                    </div>
                                    <div class="content">
                                        <span class="title">Location</span>
                                        <b class="text">64,Lakhanpur Housing
                                    Society Behind Lucky Resturant, Vikas Nagar, Kanpur, Uttar Pradesh 208024</b>
                                    </div>
                                </div>
                                <div class="contact-info-item">
                                    <div class="icon">
                                        <i class="far fa-envelope-open-text"></i>
                                    </div>
                                    <div class="content">
                                        <span class="title">Email Address</span>
                                        <b class="text"><a href="https://demo.webtend.net/cdn-cgi/l/email-protection#d7a4a2a7a7b8a5a397b0bab6bebbf9b4b8ba"><span class="__cf_email__" data-cfemail="cebdbbbebea1bcba8ea9a3afa7a2e0ada1a3">[sales@riveyrainfotec.com]</span></a></b>
                                    </div>
                                </div>
                                <div class="contact-info-item">
                                    <div class="icon">
                                        <i class="far fa-phone"></i>
                                    </div>
                                    <div class="content">
                                        <span class="title">Phone No</span>
                                        <b class="text"><a href="callto:+000(123)45699">+91 991888269</a></b>
                                    </div>
                                </div>
                            </div>
                       </div>
                   </div>
                   <div class="col-xl-5 col-lg-6">
                       <form id="contact-area-form" class="contact-area-form text-center wow fadeInRight delay-0-2s" name="contact-area-form" action="#" method="post">
                            <h4>Send us Message</h4>
                            <input type="text" id="full-name" name="full-name" class="form-control" value="" placeholder="Full Name" required="">
                            <input type="email" id="blog-email" name="blog-email" class="form-control" value="" placeholder="Email Address" required="">
                            <input type="text" id="website" name="website" class="form-control" value="" placeholder="Website" required="">
                            <textarea name="message" id="message" class="form-control" rows="5" placeholder="Write Message" required=""></textarea>
                            <button type="submit" class="theme-btn">Send messages <i class="fas fa-angle-double-right"></i></button>
                        </form>
                   </div>
               </div>
           </div>
           <div class="contact-shapes">
               <img class="shape circle" src="assets/images/shapes/slider-dots.png" alt="Shape">
               <img class="shape dots" src="assets/images/shapes/contact-dots.png" alt="Shape">
               <img class="shape wave-line" src="assets/images/shapes/contact-wave-line.png" alt="Shape">
           </div>
        </section>
        <!-- Contact Area End -->
        
        
       <!-- Blog Area start -->
       <!--  <section class="news-blog-area pt-130 pb-75 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="section-title text-center mb-60 wow fadeInUp delay-0-2s">
                            <span class="sub-title mb-15">Get Every Updates</span>
                            <h2>Read Latest News & Blog</h2>
                        </div>
                    </div>
                </div>
                <div class="row large-gap">
                    <div class="col-lg-6">
                        <div class="blog-item wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/blog/blog1.jpg" alt="Blog">
                            </div>
                            <div class="content">
                                <span class="date"><i class="far fa-calendar-alt"></i> 25 March 2022</span>
                                <h4><a href="blog-details.html">Easy Ways to Incorporate Customer Feedback</a></h4>
                                <div class="author">
                                    <img src="assets/images/blog/author1.jpg" alt="Author">
                                    <div class="post-by">
                                        <span>Post by</span>
                                        <a href="#">Douglas B. Dickens</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="blog-item wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/blog/blog2.jpg" alt="Blog">
                            </div>
                            <div class="content">
                                <span class="date"><i class="far fa-calendar-alt"></i> 27 March 2022</span>
                                <h4><a href="blog-details.html">How to create modern web site for your business?</a></h4>
                                <div class="author">
                                    <img src="assets/images/blog/author2.jpg" alt="Author">
                                    <div class="post-by">
                                        <span>Post by</span>
                                        <a href="#">Carson C. Rhodes</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="blog-item wow fadeInUp delay-0-2s">
                            <div class="image">
                                <img src="assets/images/blog/blog3.jpg" alt="Blog">
                            </div>
                            <div class="content">
                                <span class="date"><i class="far fa-calendar-alt"></i> 25 March 2022</span>
                                <h4><a href="blog-details.html">How to digital marketing work social networking?</a></h4>
                                <div class="author">
                                    <img src="assets/images/blog/author3.jpg" alt="Author">
                                    <div class="post-by">
                                        <span>Post by</span>
                                        <a href="#">Robert T. Evans</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="blog-item wow fadeInUp delay-0-4s">
                            <div class="image">
                                <img src="assets/images/blog/blog4.jpg" alt="Blog">
                            </div>
                            <div class="content">
                                <span class="date"><i class="far fa-calendar-alt"></i> 25 March 2022</span>
                                <h4><a href="blog-details.html">Easy Ways to Incorporate Customer Feedback</a></h4>
                                <div class="author">
                                    <img src="assets/images/blog/author4.jpg" alt="Author">
                                    <div class="post-by">
                                        <span>Post by</span>
                                        <a href="#">Stanley J. Contreras</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>  -->
        <!-- Blog Area end -->
        
        <?php include('footer.php');?>
        
        <!-- footer area end -->
        
        
        <!-- Scroll Top Button -->
        <button class="scroll-top scroll-to-target" data-target="html"><span class="fas fa-angle-double-up"></span></button>

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:08:28 GMT -->
</html>