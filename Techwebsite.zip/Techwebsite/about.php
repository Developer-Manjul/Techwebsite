<?php include('header.php');?>
        
        
        <!-- Page Banner Start -->
        <section class="page-banner-area pt-150 rpt-100 pb-100 rpb-100 rel z-1 bgc-black text-center " 
        style="background-image:url('assets/images/bg1.jpeg') !important;">
            <div class="container">
                <div class="banner-inner rpt-10">
                    <h1 class="page-title wow fadeInUp delay-0-2s" style="color:#fff;">abo<span>ut us</span></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center wow fadeInUp delay-0-4s">
                            <li class="breadcrumb-item"><a href="index.php" style="color:#fff;">home</a></li>
                            <li class="breadcrumb-item active" style="color:#fff;">About</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!-- <div class="banner-shapes">
                <div class="circle wow zoomInLeft delay-0-2s" data-wow-duration="2s"></div>
                <img class="shape-one" src="assets/images/shapes/hero-shape1.png" alt="Shape">
                <img class="shape-two" src="assets/images/shapes/hero-shape2.png" alt="Shape">
            </div> -->
        </section>
        <!-- Page Banner End -->
        <!--  -->
        
        <!-- What We Do Two Area start -->
        <section class="ww-do-two-area py-130 rel bgc-black z-1">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-5 col-lg-6">
                        <div class="ww-do-two-content rmb-65 wow fadeInUp delay-0-2s">
                            <div class="section-title mb-30">
                                <span class="sub-title style-two mb-15">What We Do</span>
                                <h2 style="color:#ffff;">We are Professional Digital Team</h2>
                            </div>
                            <p style="color:#fff">Start from scratch or choose from over 500 designer-made templates that you can fully  customize using the drag and drop website builder. Make your site come to life with video backgrounds</p>
                            <div class="row pt-15">
                                <div class="col-sm-6">
                                    <div class="feature-item-two border-right pe-sm-3">
                                        <div class="icon"><i class="fas fa-check"></i></div>
                                        <h5 style="color:#fff">Customize Website</h5>
                                        <p style="color:#fff">Pick a template customize anything answer or question website design just you.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="feature-item-two color-two">
                                        <div class="icon"><i class="fas fa-check"></i></div>
                                        <h5 style="color:#fff">Premium Design</h5>
                                        <p style="color:#fff">Start your own blog, add an online store and accept bookings online always.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="ww-do-btns">
                                <a href="about.php" class="theme-btn mt-15">Create Your Website <i class="fas fa-angle-double-right"></i></a>
                                <!-- <a href="https://www.youtube.com/watch?v=9Y7ma241N8k" class="mfp-iframe video-play-text mt-15"><i class="fas fa-play"></i> <span>Watch Videos</span></a> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="ww-do-two-images rel">
                            <div class="row">
                                <div class="col-sm-7 offset-1">
                                    <img class="image-one wow fadeInUp delay-0-4s" src="assets/images/about/tt3.jpg" alt="What We Do">
                                </div>
                                <div class="col-sm-4">
                                    <img class="image-two wow fadeInUp delay-0-6s" src="assets/images/about/tt1.jpg" alt="What We Do">
                                    <img class="image-three wow fadeInUp delay-0-8s" src="assets/images/about/tt2.jpg" alt="What We Do">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- What We Do Two Area end -->
        
        
        <!-- Statistics Four Area start -->
        <div class="statistics-area-four rel z-1">
            <div class="container">
                <div class="statistics-four-counters bgs-cover bgc-lighter" style="background-image: url(assets/images/background/counter-bg.png);">
                    <div class="row medium-gap">
                        <div class="col-xl-3 col-sm-6">
                            <div class="counter-item mt-30 counter-text-wrap wow fadeInLeft delay-0-2s">
                                <i class="flaticon-startup"></i>
                                <span class="count-text" data-speed="3000" data-stop="700">0</span>
                                <span class="counter-title">Projects complete</span>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6">
                            <div class="counter-item for-margin counter-text-wrap wow fadeInLeft delay-0-4s">
                                <i class="flaticon-global"></i>
                                <span class="count-text" data-speed="3000" data-stop="500">0</span>
                                <span class="counter-title">Trusted Global Clients</span>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6">
                            <div class="counter-item mt-20 counter-text-wrap wow fadeInLeft delay-0-6s">
                                <i class="flaticon-rating"></i>
                                <span class="count-text" data-speed="3000" data-stop="100">0</span>
                                <span class="counter-title">Expert Team Member</span>
                            </div>
                        </div>
                        <div class="col-xl-3 col-sm-6">
                            <div class="counter-item for-margin counter-text-wrap wow fadeInLeft delay-0-8s">
                                <i class="flaticon-trophy"></i>
                                <span class="count-text" data-speed="3000" data-stop="700">0</span>
                                <span class="counter-title">Projects complete</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Statistics Four Area end -->
        
        
        
        
        
        <!-- Team Area start -->
        <section class="team-slider-area pt-210 pb-130 rel z-1">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section-title text-center mb-50">
                            <span class="sub-title style-two mb-15">Amazing Team</span>
                            <h2>We Have Well Experience Team Member</h2>
                        </div>
                    </div>
                </div>
                <div class="team-slider-active">
                    <div class="team-member wow fadeInUp delay-0-2s">
                        <div class="image">
                            <img src="assets/images/team/member1.jpg" alt="Member">
                        </div>
                        <div class="content">
                            <h5><a href="team-profile.html">Vaibhav Gupta</a></h5>
                            <span class="designation">CEO</span>
                            <span class="designation">Director</span>
                            <div class="social-style-one">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-member wow fadeInUp delay-0-4s">
                        <div class="image">
                            <img src="assets/images/team/member2.jpg" alt="Member">
                        </div>
                        <div class="content">
                            <h5><a href="team-profile.html">Richard C. Harrison</a></h5>
                            <span class="designation">Web Developer</span>
                            <div class="social-style-one">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="team-member wow fadeInUp delay-0-6s">
                        <div class="image">
                            <img src="assets/images/team/member3.jpg" alt="Member">
                        </div>
                        <div class="content">
                            <h5><a href="team-profile.html">Vishal Soni</a></h5>
                            <span class="designation">Developer</span>
                            <div class="social-style-one">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
     
                   
                </div>
            </div>
        </section>
        <!-- Team Area end -->
        
        
        <!-- Feature Six Area start -->
        <section class="freature-area-six rel z-2">
            <div class="container">
                <div class="feature-six-inner bgs-cover bgc-primary" style="background-image: url(assets/images/background/freature-bg-line.png);">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="feature-item-three wow fadeInRight delay-0-3s">
                                <i class="flaticon-technical-support"></i>
                                <div class="content">
                                    <h4>Customize your site</h4>
                                    <p>Sit amet consectetur adipiscing sed eiusmod tempor incididunt labore et dolore magnaes epsums</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="feature-item-three color-two wow fadeInRight delay-0-5s">
                                <i class="flaticon-app-development"></i>
                                <div class="content">
                                    <h4>Edit your mobile view</h4>
                                    <p>Sit amet consectetur adipiscing sed eiusmod tempor incididunt labore et dolore magnaes epsums</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="feature-item-three color-three wow fadeInRight delay-0-4s">
                                <i class="flaticon-settings"></i>
                                <div class="content">
                                    <h4>Add advanced features</h4>
                                    <p>Sit amet consectetur adipiscing sed eiusmod tempor incididunt labore et dolore magnaes epsums</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="feature-item-three color-four wow fadeInRight delay-0-6s">
                                <i class="flaticon-optimization"></i>
                                <div class="content">
                                    <h4>Optimize for search engines</h4>
                                    <p>Sit amet consectetur adipiscing sed eiusmod tempor incididunt labore et dolore magnaes epsums</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Feature Six Area end -->
        
        
        <!-- Feedback Area start -->
        <section class="feedback-area bgc-black pt-250 pb-130 rel z-1">
            <div class="container pt-130">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title text-center mb-40 wow fadeInUp delay-0-2s">
                            <span class="sub-title style-two mb-20" style="color:#ffff">Clents Feedback</span>
                            <h2></h2>
                        </div>
                    </div>
                </div>
                <div class="feedback-active">
                    <div class="feedback-item wow fadeInUp delay-0-2s">
                       <!--  <div class="author-logo">
                            <i class="far fa-quote-right"></i>
                            <img src="assets/images/feedback/logo1.png" alt="Logo">
                        </div> -->
                        <h4>On the other hand denounes with indignwy</h4>
                        <p>Riveyra Infotech was able to replicate the ideas that were only in my mind into a real website and this is for me one of the incredible qualities of a web design company to be able to put what your clients want you to. Also, they were pretty diligent in keeping me up to date with the progress of the project and time and again ensured that I am completely satisfied with how things are going. I would urge all those who want quality product and stellar services to contact Riveyra Infotech today.</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>Jyoti Jyoti</h5>
                            </div>
                        </div>
                    </div>
                    <div class="feedback-item wow fadeInUp delay-0-4s">
                        <!-- <div class="author-logo">
                            <i class="far fa-quote-right"></i>
                            <img src="assets/images/feedback/logo2.png" alt="Logo">
                        </div> -->
                        <h4>Custom programming fores most complex functions</h4>
                        <p>Absolutely anything needed for website development, they have it! I would like to thank a very very supportive team and cooperative environment that takes care of every single detail required by the customer, and also for their exceptional service for increasing web traffic by a great amount! Really must appreciate the fair and competitive pricing for such commendable work. Never expected results this good.....</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>Kamya Tiwari</h5>
                            </div>
                        </div>
                    </div>
                    <div class="feedback-item wow fadeInUp delay-0-6s">
                        
                        <h4>We use strategic marketing tactics be proven work.</h4>
                        <p>When I approached Riveyra Infotech for my website redesigning project, I was pretty clear that I didn’t want them to change the format of my website; I just want certain new functions to be incorporated in the website. I think it is because of their extensive experience that they were able to add on so many new innovations without impacting the actual layout. I am now planning to hand them over the responsibility to make my website more visible online, which I know they’ll do beautifully.</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>Jaya Kushwaha</h5>
                            </div>
                        </div>
                    </div>
                    <div class="feedback-item wow fadeInUp delay-0-2s">
                        <h4>On the other hand denounes with indignwy</h4>
                        <p>My new pet food company partnered with Riveyra Infotech to help build our new website and eCommerce platform.  From day one they were extremely helpful in answering our questions and providing valuable guidance.  They provided honest feedback on our ideas and helped us build the content for the site. Their project management structure was great as it allowed all participants to stay up to date on the project and view changes in one place.  Our website and online shop was completed on-time and we could not be happier with the finished product.   We will continue to use Riveyra for any future development work..
                            thanks Mr. Vaibhav and team...</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>Piyush Gupta</h5>
                            </div>
                        </div>
                    </div>
                    <div class="feedback-item wow fadeInUp delay-0-2s">
                        <h4>Custom programming fores most complex functions</h4>
                        <p>I am really impressed by Riveyra Infotech knowledge, experience, and focus, their drive to explore new nooks of website design and development and passion to deliver the best. I was enthralled by the way they transition their thinking and functioning with each phase that brings out the best for the project overall.</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>Suryansh Awasthi</h5>
                            </div>
                        </div>
                    </div>
                    <div class="feedback-item wow fadeInUp delay-0-2s">
                        <h4>We use strategic marketing tactics be proven work.</h4>
                        <p>I am really happy with your services, it is exceptional, Riveyra Infotech  is just great. When I have a question they answer it at once, they have more than an outstanding customer service. After having a bad experience with my old Web Designer Company, I would say that, Riveyra Infotech  team is  very professional and their knowledge is incredible, they also solve problems very fast, I am impressed. I recommend , Riveyra Infotech to all.</p>
                        <div class="feedback-author">
                            <div class="content">
                                <h5>ASHMIX MEDIA AND ADVERTISIMENT PRIVETED LIMITED</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="feedback-shape one">
                <img src="assets/images/feedback/man1.jpg" alt="Man Shape">
            </div>
            <div class="feedback-shape two">
                <img src="assets/images/feedback/man2.jpg" alt="Man Shape">
            </div>
        </section>
        <!-- Feedback Area end -->
        
        
        <!-- Call to Action Area start -->
        <section class="call-to-action-area bgc-black pt-80 pb-50">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-7 col-lg-9">
                        <div class="section-title text-white mb-25 wow fadeInUp delay-0-2s">
                            <h2>Let’s Design Your New Website</h2>
                            <p>Do you want to have a website that stands out and impresses your clients? Then we are ready to help! Click the button below to contact us and discuss your ideas.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 text-lg-end">
                        <a href="contact.php" class="theme-btn style-two mb-30 wow fadeInUp delay-0-4s">Let’s Intersted <i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Area End -->
        
        
        <!-- footer area start -->

        <?php include('footer.php');?>
        
        <!-- footer area end -->

    </div>
    <!--End pagewrapper-->
   
    
    <!-- Jquery -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Appear Js -->
    <script src="assets/js/appear.min.js"></script>
    <!-- Slick -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Nice Select -->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!-- Image Loader -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- Type Writer -->
    <script src="assets/js/jquery.animatedheadline.min.js"></script>
    <!-- Circle Progress -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- Isotope -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>

</body>

<!-- Mirrored from demo.webtend.net/html/oxence/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Oct 2022 23:11:26 GMT -->
</html>